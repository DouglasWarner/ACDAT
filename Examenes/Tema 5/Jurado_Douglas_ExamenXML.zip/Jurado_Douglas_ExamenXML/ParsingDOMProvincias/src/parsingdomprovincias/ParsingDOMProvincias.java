/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsingdomprovincias;


import java.io.File;
import java.io.FileNotFoundException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author douglas
 */
public class ParsingDOMProvincias {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
        String nomFichero;
        String textoDeBusqueda;
        
        if(args.length < 1)
        {
            System.out.println("Indica el nombre del fichero XML");
            return;
        }
        if(args.length < 2)
        {
            System.out.println("Indica la localidad a buscar");
            return;
        }
        
        nomFichero = args[0];
        textoDeBusqueda = args[1];
        
        DocumentBuilderFactory documento = DocumentBuilderFactory.newInstance();
        documento.setIgnoringComments(true);
        documento.setIgnoringElementContentWhitespace(true);
        
        try
        {
            DocumentBuilder db = documento.newDocumentBuilder();
            Document docDOM = db.parse(new File(nomFichero));
            
            System.out.println("Buscando localidades cuyo nombre contiene " + textoDeBusqueda);
            BuscarLocalidad(docDOM, textoDeBusqueda);            
        }
        catch (FileNotFoundException | ParserConfigurationException | SAXException e)
        {
            System.err.println(e.getMessage());
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
    }
   
   public static void BuscarLocalidad(Node n, String patron)
   {    
       if(n.getNodeType() == Node.TEXT_NODE)
       {
          String texto = n.getNodeValue();
          if(texto.trim().length() == 0)
              return;
       }
       
       String idProvincia = "";
       String nombreLocalidad;
       
        if(n.getNodeType() == Node.ELEMENT_NODE)
        {
            if(n.getNodeName() == "localidad")
            {
                nombreLocalidad = n.getTextContent();

                if(nombreLocalidad.toUpperCase().contains(patron.toUpperCase()))
                {                    
                    idProvincia = n.getParentNode().getParentNode().getAttributes().item(0).getTextContent();
                    
                    System.out.println(nombreLocalidad + " ["+ idProvincia +"]");
                }
            }
        }
        
        NodeList nodos = n.getChildNodes();
        
        for (int i = 0; i < nodos.getLength(); i++) 
        {
           BuscarLocalidad(nodos.item(i), patron);
        }
                
   }
    
}
