/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsingsaxprovincias;

import java.io.PrintStream;
import java.util.LinkedList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author douglas
 */
public class ParsingSAXProvincias {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nomFich;
        String codigo;
        
        if (args.length < 1) {
            System.out.println("Indica por favor nombre de fichero");
            return;
        } 
        if(args.length < 2){
            System.out.println("Indica el codigo de la provincia a buscar");
            return;
        }
        
        nomFich = args[0];
        codigo = args[1];
        
        try {
            XMLReader parserSAX = XMLReaderFactory.createXMLReader();
            GestorEventos gestorEventos = new GestorEventos(System.out, args[1]);
            parserSAX.setContentHandler(gestorEventos);
            parserSAX.parse(nomFich);
        } catch (SAXException e) {
            System.err.println(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }    
}

class GestorEventos extends DefaultHandler
{
    private final PrintStream ps;
    private String codigoProvincia;
    private String nombreProvincia;
    private LinkedList<String> localidades;
    private boolean enProvincia;
    private boolean enLocalidades;
        
    public GestorEventos(PrintStream ps, String codigo) {
        this.ps = ps;
        codigoProvincia = codigo;
        localidades = new LinkedList<>();
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        
        if(localName.equals("provincia"))
        {
            String tmpProvincia = attributes.getValue("id");
            if(tmpProvincia.equals(codigoProvincia))
            {
                System.out.println("    ID Provincia: " + tmpProvincia);
                enProvincia = true;
            }
            else
                enProvincia = false;
        }
        
        if(qName.equals("localidad") && enProvincia)
            enLocalidades = true;
        
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
                
        if(localName.equals("provincia") && enProvincia)
        {
            enProvincia = !enProvincia;
            enLocalidades = !enLocalidades;
            System.out.println("    Provincia: " + nombreProvincia);
            System.out.println("        Localidades");
            System.out.println("==============================");
            for (String localidad : localidades) {
                System.out.println(localidad);
            }
            
            localidades = new LinkedList<>();
        }        
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String texto = new String(ch,start,length);
        if(texto.trim().length() == 0)
            return;
        
        if(enProvincia && !enLocalidades)
            nombreProvincia = texto;
        
        if(enLocalidades && enProvincia)
            localidades.add(texto);
    }
    
    @Override
    public void fatalError(SAXParseException e) throws SAXParseException {
        System.err.print(e);
        throw(e);
    }

    @Override
    public void error(SAXParseException e) throws SAXParseException {
        System.err.print(e);
        throw(e);
    }

    @Override
    public void warning(SAXParseException e) throws SAXParseException {
        System.err.print(e);
        throw(e);
    }
}
