/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xpathinfoprovincias;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathException;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author douglas
 */
public class XPathInfoProvincias {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nomFich;
        String consultaProvincia;
        File fichero;
        
        if(args.length < 1)
        {
            System.out.println("Indica el nombre del fichero XML");
            return;
        }
        if(args.length < 2)
        {
            System.out.println("Indica el codigo de la provincia a buscar");
            return;
        }
        
        nomFich = args[0];
        consultaProvincia = "//provincia[@id=\"" + args[1] + "\"]";
        
        fichero = new File(nomFich);
        if(!fichero.exists())
        {
            System.out.println("El fichero no existe");
            return;
        }
        
        System.out.printf("Código de la provincia: %s\n", args[1]);
        
        try
        {
           Document docXML = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(fichero);
           XPathExpression xPathExp = XPathFactory.newInstance().newXPath().compile(consultaProvincia);
           NodeList resultados = (NodeList) xPathExp.evaluate(docXML, XPathConstants.NODESET);
           
            
           System.out.println(" Nombre: " + resultados.item(0).getTextContent());
                      
           
           if(resultados.getLength() < 1)
               System.out.println("No existe una provincia con el código indicado.");
        }
        catch (SAXException | XPathException e) 
        {
            System.err.println(e.getMessage());
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
    
}
