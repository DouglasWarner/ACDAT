/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package muestraficherocsv;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author douglas
 */
public class MuestraFicheroCSV {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String ficheroCSV = "/home/douglas/Escritorio/personas.csv";
        
        File fich = new File(ficheroCSV);
        
        if(!fich.exists())
        {
            System.err.print("El fichero no existe");
            return;
        }
        
        String linea = "";
        StringBuilder contenido = new StringBuilder();
        String palabra = "";
        int contadorCampo = 1;
        int contadorLinea = 0;
        
        try (BufferedReader bfr = new BufferedReader(new FileReader(fich)))
        {
            while((linea = bfr.readLine()) != null)
            {
                contadorCampo = 1;
                contadorLinea++;
                
                contenido.append(linea);
                System.out.format("Linea%s=>", contadorLinea);
                
                for (int i = 0; i < contenido.length(); i++) {
                    palabra += contenido.charAt(i);
                    if(contenido.charAt(i) == ',')
                    {
                        System.out.format("Campo %s: %s ", contadorCampo, palabra);
                        palabra = "";
                        contadorCampo++;
                    }                    
                }
                System.out.format("Campo %s: %s ", contadorCampo, palabra);
                palabra = "";
                contenido = new StringBuilder();
                System.out.println();
            }
        }
        catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
    }
    
}
