/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficheroaccesoaleatorio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;

public class FicheroAccesoAleatorio {    
    
    static File ficheroAlea;
    static final int LONG = 20;
    
    public FicheroAccesoAleatorio(File fich)
    {
        ficheroAlea = fich;
    }
    
    public void Insertar(int posicion, String nombre)
    {
        try(RandomAccessFile ficheroLeer = new RandomAccessFile(ficheroAlea,"rws")) {
            
            for(int i=nombre.length()+1; i<=LONG; i++) {
                nombre += " ";
            }
            
            ficheroLeer.seek((posicion-1)*LONG);
            
            ficheroLeer.write(nombre.getBytes("UTF-8"),0,LONG);
            
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e)
        {
            System.out.println(e.getMessage());
        }
        
    }
    
    public void Leer(File fichero)
    {
        String leido = "";
        String result = "";
        char[] longitud = new char[LONG];
        int pos = 0;
        long finFichero = fichero.length();
        
        try(BufferedReader fichLeer = new BufferedReader(new FileReader(fichero))) 
        {            
            while((leido = fichLeer.readLine()) != null)
            {
                for (int i = 0; i < leido.length(); i++) {
                    if(leido.charAt(i) == ',')
                    {
                        pos = Integer.parseInt(leido.substring(i+1));
                        result = leido.substring(0,i-1);
                    }
                }
                Insertar(pos, result);
            }            
        } catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
        } catch (IOException e)
        {
            System.err.println(e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        File fichero = new File("/home/douglas/Escritorio/ficheroaleatorio");
        
        FicheroAccesoAleatorio fa = new FicheroAccesoAleatorio(fichero);
        
        fa.Leer(fichero);
    }
}
