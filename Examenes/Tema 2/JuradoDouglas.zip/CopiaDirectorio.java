/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package copiadirectorio;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author douglas
 */
public class CopiaDirectorio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
        if(args.length < 2)
        {
            System.err.println("Error al pasar lo argumentos. Primer parametro: Directorio a copiar. Segundo parametro: Directorio destino a pegar.");
            return;
        }
        String directorioOrigen = args[0];
        String directorioDestino = args[1];
        
        File fdo = new File(directorioOrigen);
        File fdd = new File(directorioDestino);
        
        if(!fdo.exists())
        {
            System.err.println("El primer directorio pasado no existe");
            return;
        }
        if(!fdo.isDirectory())
        {
            System.err.println("El primer directorio debe ser un directorio");
            return;
        }
        fdd.delete();
        if(fdd.exists())
        {
            System.err.println("El segundo directorio pasado debe no existir");
            return;
        }
        fdd.mkdir();
        if(!fdd.isDirectory())
        {
            System.err.println("El segundo parametro debe ser un directorio");
            return;
        }
        
        File[] listaFicheros = fdo.listFiles();
        
        for (int i = 0; i < listaFicheros.length; i++) {
            if(!listaFicheros[i].isDirectory())
            {
                System.out.println("Copiando: " + listaFicheros[i]);
                try(BufferedInputStream bfi = new BufferedInputStream(new FileInputStream(listaFicheros[i])); 
                BufferedOutputStream bfo = new BufferedOutputStream(new FileOutputStream(new File(fdd, listaFicheros[i].getName()))))
                {
                    bfi.transferTo(bfo);
                } catch (FileNotFoundException ex) {
                    System.err.println(ex.getMessage());
                } catch (IOException ex) {
                    System.err.println(ex.getMessage());
                }
            }
        }
    }
    
    
}
